import Link from "next/link";
import { socialLinks as defaultSocialLinks } from "@/lib/portfolio-data";
import { SocialIcon, SocialIconName } from "@/components/ui/SocialIcon";
import { EmailLink } from "@/components/ui/EmailLink";
import { DynamicCopyright } from "@/components/ui/DynamicCopyright";

export interface SocialLinkItem {
  label: string;
  href: string;
  icon: SocialIconName;
}

export interface FooterProps {
  email?: string;
  socialLinks?: SocialLinkItem[];
}

export function Footer({
  email = "bijoysarkar7252@gmail.com",
  socialLinks = defaultSocialLinks,
}: FooterProps) {
  return (
    <footer className="site-footer" id="footer">
      <div className="section-wrap">
        <div className="footer-main">
          <div className="footer-identity">
            <Link className="brand-lockup" href="/#home" aria-label="Bijoy Sarkar, return to top">
              <span className="brand-mark brand-avatar">
                <img
                  src="/avatar.png"
                  alt="Bijoy Sarkar"
                  width={32}
                  height={32}
                  className="brand-avatar-img"
                />
              </span>
              <span className="brand-name">
                Bijoy Sarkar<small>Software Engineer &amp; AI Developer</small>
              </span>
            </Link>
            <p>Building intelligent systems and full-stack solutions.</p>
          </div>
          <div>
            <h2 className="footer-heading">Navigate</h2>
            <div className="footer-links">
              <Link href="/#home">Home</Link>
              <Link href="/#about">About</Link>
              <Link href="/#projects">Projects</Link>
              <Link href="/#resume">Resume</Link>
              <Link href="/#games">Games</Link>
              <Link href="/#contact">Contact</Link>
            </div>
          </div>
          <div>
            <h2 className="footer-heading">Find me online</h2>
            <div className="social-links">
              {socialLinks.map(({ label, href, icon }) => (
                <a
                  className="social-link"
                  href={href}
                  key={label}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`${label} profile`}
                >
                  <SocialIcon name={icon} size={15} />
                </a>
              ))}
            </div>
            <EmailLink className="footer-email" email={email} />
          </div>
        </div>
        <div className="footer-bottom">
          <DynamicCopyright />
          <span>Built with curiosity and care.</span>
        </div>
      </div>
    </footer>
  );
}
