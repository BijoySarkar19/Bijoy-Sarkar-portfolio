"use client";

import { useState, useEffect, useRef, useMemo } from "react";
import {
  Save,
  Undo2,
  Moon,
  Sun,
  Check,
  Sheet,
  GraduationCap,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  ExternalLink,
  MapPin,
  Layers,
  Sparkles,
  BookOpen,
  Upload,
  EyeOff,
  RotateCcw,
  Search,
  X,
  Sliders,
} from "lucide-react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { DEFAULT_DEGREES, type DegreeItem } from "@/lib/degrees";
import { applyThemeVariables } from "@/components/ui/ClientThemeSync";

export interface SiteSettingsMap {
  heroTitle?: string;
  heroSubhead?: string;
  heroBio?: string;
  contactEmail?: string;
  contactRecipientEmail?: string;
  location?: string;
  locationMapUrl?: string;
  currentLocation?: string;
  currentLocationMapUrl?: string;
  displayAddressMode?: string;
  status?: string;
  githubUrl?: string;
  linkedinUrl?: string;
  twitterUrl?: string;
  instagramUrl?: string;
  facebookUrl?: string;
  youtubeUrl?: string;
  discordUrl?: string;
  googleSheetsWebhookUrl?: string;
  themeAccent?: string;
  themeMode?: string;
  // CV Watermark Controls (Edit & Remove)
  cvWatermarkEnabled?: string;
  cvWatermarkText?: string;
  cvWatermarkOpacity?: string;
  cvWatermarkAngle?: string;
  // Project Artwork & Gallery Defaults
  ongoingDefaultImage?: string;
  defaultProjectImageCount?: string;
  // Section Visibility Toggles
  heroEnabled?: string;
  aboutEnabled?: string;
  skillsEnabled?: string;
  projectsEnabled?: string;
  resumeEnabled?: string;
  gamesEnabled?: string;
  contactEnabled?: string;
  // Section Editorial Texts
  aboutTitle?: string;
  aboutBio?: string;
  aboutLead?: string;
  skillsTitle?: string;
  skillsSubtitle?: string;
  projectsTitle?: string;
  projectsSubtitle?: string;
  ongoingTitle?: string;
  ongoingSubtitle?: string;
  resumeTitle?: string;
  resumeSubtitle?: string;
  gamesTitle?: string;
  gamesSubtitle?: string;
  contactTitle?: string;
  contactSubtitle?: string;
  // Degrees JSON
  degreesList?: string;
  [key: string]: string | undefined;
}

const ACCENT_PRESETS = [
  { name: "Cyber Orange", hex: "#ff5e2c" },
  { name: "Electric Blue", hex: "#00b4d8" },
  { name: "Neon Violet", hex: "#9d4edd" },
  { name: "Matrix Emerald", hex: "#00f5d4" },
  { name: "Crimson Red", hex: "#e63946" },
];

export function SettingsManager({ initialSettings }: { initialSettings: SiteSettingsMap }) {
  const router = useRouter();
  const [settings, setSettings] = useState<SiteSettingsMap>(() => {
    if (typeof window !== "undefined") {
      try {
        const local = localStorage.getItem("admin_site_settings");
        if (local) {
          const parsed = JSON.parse(local);
          return { ...initialSettings, ...parsed };
        }
      } catch {}
    }
    return initialSettings;
  });
  const [loading, setLoading] = useState(false);
  const [lastAuditId, setLastAuditId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error"; canUndo?: boolean } | null>(null);

  // Degrees state
  const [degrees, setDegrees] = useState<DegreeItem[]>(() => {
    if (typeof window !== "undefined") {
      try {
        const localDegrees = localStorage.getItem("admin_degrees_list");
        if (localDegrees) {
          const parsed = JSON.parse(localDegrees);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      } catch {}
    }
    try {
      if (initialSettings.degreesList) {
        const parsed = JSON.parse(initialSettings.degreesList);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Error parsing degreesList:", e);
    }
    return DEFAULT_DEGREES;
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingArtwork, setUploadingArtwork] = useState(false);

  // Settings Search Bar & Live Suggestions State
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const SETTINGS_SECTIONS_INDEX = useMemo(() => [
    { id: "sec-visibility", title: "Section Visibility Toggles", category: "Modules", keywords: ["hero", "about", "skills", "projects", "resume", "cv", "games", "contact", "visibility", "toggles", "enable", "disable"] },
    { id: "sec-identity", title: "Profile & Identity (Hero Headline)", category: "Identity", keywords: ["hero", "headline", "bio", "title", "subhead", "status", "open to opportunities"] },
    { id: "sec-location", title: "Location, Maps & Address Mode", category: "Location", keywords: ["location", "address", "map", "agartala", "tripura", "india", "current", "permanent", "dual", "single"] },
    { id: "sec-contact", title: "Contact & Gmail Alert Settings", category: "Contact", keywords: ["email", "contact", "bijoysarkar7252@gmail.com", "webhook", "google sheets", "alerts"] },
    { id: "sec-watermark", title: "CV Watermark Controls (Edit & Remove)", category: "Curriculum Vitae", keywords: ["watermark", "cv", "resume", "confidential", "opacity", "angle", "remove watermark", "edit watermark", "watermark text"] },
    { id: "sec-social", title: "Social Profiles & Links", category: "Social", keywords: ["github", "linkedin", "twitter", "x", "instagram", "facebook", "youtube", "discord"] },
    { id: "sec-degrees", title: "Education & Academic Degrees", category: "Education", keywords: ["degree", "education", "icfai", "b.tech", "computer science", "university"] },
    { id: "sec-theme", title: "Theme Accent & Color Appearance", category: "Appearance", keywords: ["theme", "accent", "color", "orange", "blue", "violet", "emerald", "red", "dark mode", "light mode"] },
    { id: "sec-artwork", title: "Default Project Artwork & Layout", category: "Projects", keywords: ["artwork", "ongoing", "cover", "image", "layout", "single hero"] },
    { id: "sec-editorial", title: "Editorial Headings & Subtitles", category: "Copywriting", keywords: ["editorial", "headings", "subtitles", "about title", "skills title", "projects title", "resume title", "games title", "contact title"] },
  ], []);

  const suggestions = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return [];
    return SETTINGS_SECTIONS_INDEX.filter((item) =>
      item.title.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q) ||
      item.keywords.some((k) => k.toLowerCase().includes(q))
    ).slice(0, 8);
  }, [SETTINGS_SECTIONS_INDEX, searchQuery]);

  useEffect(() => {
    const activeAccent = settings.themeAccent || "#ff5e2c";
    const activeMode = settings.themeMode || "dark";
    applyThemeVariables(activeAccent, activeMode);
  }, [settings.themeAccent, settings.themeMode]);

  function getMatchingOngoingCover(accent: string, isFullBleed?: boolean): string {
    const hex = accent.toLowerCase().trim();
    const fullbleed =
      typeof isFullBleed === "boolean"
        ? isFullBleed
        : Boolean((settings.ongoingDefaultImage || "").includes("fullbleed"));

    let colorName = "orange";
    if (hex === "#9d4edd" || hex.includes("violet") || hex.includes("purple")) colorName = "violet";
    else if (hex === "#00b4d8" || hex.includes("blue")) colorName = "blue";
    else if (hex === "#00f5d4" || hex.includes("emerald") || hex.includes("green")) colorName = "emerald";
    else if (hex === "#e63946" || hex.includes("red") || hex.includes("crimson")) colorName = "red";

    return fullbleed
      ? `/images/ongoing-project-cover-fullbleed-${colorName}.webp`
      : `/images/ongoing-project-cover-${colorName}.webp`;
  }

  async function handleCustomPhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    // Instant local preview
    const localUrl = URL.createObjectURL(file);
    handleChange("ongoingDefaultImage", localUrl);

    setUploadingArtwork(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload-artwork", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to upload image");
      handleChange("ongoingDefaultImage", data.url);
      setMessage({
        text: `Custom photo "${file.name}" uploaded and set as default ongoing artwork!`,
        type: "success",
      });
    } catch (err) {
      setMessage({
        text: err instanceof Error ? err.message : "Image upload failed.",
        type: "error",
      });
    } finally {
      setUploadingArtwork(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function handleRemovePhoto() {
    handleChange("ongoingDefaultImage", "");
    setMessage({
      text: "Ongoing project default photo removed. Projects will show the clean 'Upcoming on his way' indicator unless an image is set.",
      type: "success",
    });
  }

  function handleChange(key: string, value: string) {
    setSettings((prev) => {
      const next = { ...prev, [key]: value };

      if (key === "themeAccent") {
        applyThemeVariables(value, next.themeMode);
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem("site_theme_accent", value);
            document.cookie = `portfolio_theme_accent=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
            window.dispatchEvent(new CustomEvent("portfolio-theme-change", { detail: { accent: value, mode: next.themeMode } }));
          } catch {}
        }
        // Automatically switch ongoing artwork to match selected accent theme (preserving Style 1 or Style 2)
        const currentCover = prev.ongoingDefaultImage || "";
        if (currentCover && currentCover.includes("ongoing-project-cover")) {
          const isFullBleed = currentCover.includes("fullbleed");
          next.ongoingDefaultImage = getMatchingOngoingCover(value, isFullBleed);
        }
      }

      if (key === "themeMode") {
        applyThemeVariables(next.themeAccent || "#ff5e2c", value);
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem("site_theme_mode", value);
            document.cookie = `portfolio_theme_mode=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
            window.dispatchEvent(new CustomEvent("portfolio-theme-change", { detail: { accent: next.themeAccent, mode: value } }));
          } catch {}
        }
      }

      if (key === "ongoingDefaultImage" && typeof window !== "undefined") {
        try {
          document.cookie = `portfolio_ongoing_image=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
        } catch {}
      }

      return next;
    });
  }

  function handleAddDegree() {
    const newDegree: DegreeItem = {
      id: `degree-${Date.now()}`,
      degree: "M.Tech · Computer Science & Engineering",
      institution: "Institution / University Name",
      link: "https://",
      period: "2027—2029",
      showOnHome: true,
    };
    setDegrees((prev) => [...prev, newDegree]);
  }

  function handleUpdateDegree(id: string, field: keyof DegreeItem, value: any) {
    setDegrees((prev) => prev.map((d) => (d.id === id ? { ...d, [field]: value } : d)));
  }

  function handleDeleteDegree(id: string) {
    if (degrees.length <= 1) {
      if (!window.confirm("Are you sure you want to remove this degree? At least one degree is recommended.")) return;
    }
    setDegrees((prev) => prev.filter((d) => d.id !== id));
  }

  function handleMoveDegree(index: number, direction: "up" | "down") {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= degrees.length) return;
    setDegrees((prev) => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    const payload = {
      ...settings,
      degreesList: JSON.stringify(degrees),
    };

    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to save settings.");

      if (data.settings) {
        setSettings(data.settings);
      }

      // Immediately apply theme variables across whole document
      const activeAccent = settings.themeAccent || "#ff5e2c";
      const activeMode = settings.themeMode || "dark";
      applyThemeVariables(activeAccent, activeMode);

      setLastAuditId(data.auditLogId || null);

      if (typeof window !== "undefined") {
        try {
          localStorage.setItem("site_theme_accent", activeAccent);
          localStorage.setItem("site_theme_mode", activeMode);
          localStorage.setItem("admin_site_settings", JSON.stringify(data.settings || payload));
          localStorage.setItem("admin_degrees_list", JSON.stringify(degrees));
          document.cookie = `portfolio_theme_accent=${encodeURIComponent(activeAccent)}; path=/; max-age=31536000; SameSite=Lax`;
          document.cookie = `portfolio_theme_mode=${encodeURIComponent(activeMode)}; path=/; max-age=31536000; SameSite=Lax`;
          if (settings.ongoingDefaultImage) {
            document.cookie = `portfolio_ongoing_image=${encodeURIComponent(settings.ongoingDefaultImage)}; path=/; max-age=31536000; SameSite=Lax`;
          }
          window.dispatchEvent(new CustomEvent("portfolio-theme-change", { detail: { accent: activeAccent, mode: activeMode } }));
        } catch {}
      }

      setMessage({
        text: "Portfolio settings, sections, degrees, and content updated and saved! Recorded in audit log.",
        type: "success",
        canUndo: Boolean(data.auditLogId),
      });
      router.refresh();
    } catch (err: unknown) {
      setMessage({ text: err instanceof Error ? err.message : "Error saving settings.", type: "error" });
    } finally {
      setLoading(false);
    }
  }

  async function handleUndo() {
    if (!lastAuditId) return;
    setLoading(true);
    try {
      const res = await fetch("/api/admin/undo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ auditLogId: lastAuditId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Undo failed.");

      setMessage({ text: `↩ Undone: ${data.message}`, type: "success" });
      setLastAuditId(null);

      const refreshRes = await fetch("/api/admin/settings");
      const refreshData = await refreshRes.json();
      if (refreshData.settings) {
        setSettings(refreshData.settings);
        if (typeof window !== "undefined") {
          try {
            localStorage.setItem("admin_site_settings", JSON.stringify(refreshData.settings));
          } catch {}
        }
        if (refreshData.settings.degreesList) {
          try {
            const parsedDegrees = JSON.parse(refreshData.settings.degreesList);
            setDegrees(parsedDegrees);
            if (typeof window !== "undefined") {
              try {
                localStorage.setItem("admin_degrees_list", JSON.stringify(parsedDegrees));
              } catch {}
            }
          } catch {}
        }
      }
      router.refresh();
    } catch (err: unknown) {
      setMessage({ text: err instanceof Error ? err.message : "Failed to undo settings.", type: "error" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="admin-crud-panel">
      {message && (
        <div
          className={message.type === "success" ? "admin-success" : "admin-alert"}
          role="status"
          style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
        >
          <span>{message.text}</span>
          {message.canUndo && lastAuditId && (
            <button
              type="button"
              onClick={handleUndo}
              disabled={loading}
              className="admin-small-button"
              style={{
                background: "rgba(255, 94, 44, 0.2)",
                border: "1px solid var(--orange)",
                color: "var(--white)",
                fontWeight: 700,
              }}
            >
              <Undo2 size={12} /> Undo this change
            </button>
          )}
        </div>
      )}

      <div className="admin-crud-header">
        <div>
          <h2>Site Settings &amp; Configuration</h2>
          <p className="admin-form-help">
            Customize hero headline, section modules, editorial texts, degrees, addresses, and color accents. All edits are logged in IST and reversible.
          </p>
        </div>
      </div>

      {/* Settings Search Bar with Live Suggestions */}
      <div className="admin-search-container" ref={searchContainerRef} style={{ marginTop: 6, marginBottom: 20 }}>
        <div className="admin-search-bar">
          <Search size={15} style={{ color: "var(--orange)", flexShrink: 0 }} />
          <input
            type="text"
            className="admin-search-input"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search settings by field name, category, or keyword..."
            aria-label="Search settings and configuration"
          />
          {searchQuery && (
            <button
              type="button"
              className="admin-search-clear"
              onClick={() => {
                setSearchQuery("");
                setShowSuggestions(false);
              }}
              title="Clear search"
            >
              <X size={14} />
            </button>
          )}
          {searchQuery && (
            <span className="admin-search-badge">
              {suggestions.length} {suggestions.length === 1 ? "section" : "sections"}
            </span>
          )}
        </div>

        {/* Suggestions Popover */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="admin-suggestions-popover">
            {suggestions.map((sug, idx) => (
              <div
                key={`${sug.id}-${idx}`}
                className="admin-suggestion-item"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setSearchQuery(sug.title);
                  setShowSuggestions(false);
                  const el = document.getElementById(sug.id);
                  if (el) {
                    el.scrollIntoView({ behavior: "smooth", block: "center" });
                    el.style.outline = "2px solid var(--orange)";
                    setTimeout(() => {
                      el.style.outline = "";
                    }, 2500);
                  }
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                  <Sliders size={13} style={{ color: "var(--orange)", flexShrink: 0 }} />
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, color: "var(--white)", fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {sug.title}
                    </div>
                    <div style={{ fontSize: 11, color: "var(--muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      Category: {sug.category} · Jump to configuration
                    </div>
                  </div>
                </div>
                <span className="admin-suggestion-tag">{sug.category}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="admin-form">
        <div
          className="admin-grid"
          style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))", gap: 20 }}
        >
          {/* Section Visibility Modules (Image 2 request) */}
          <div id="sec-visibility" className="admin-card" style={{ gridColumn: "1 / -1" }}>
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Portfolio Modules</p>
                <h3>Section Visibility Toggles</h3>
              </div>
            </div>
            <p className="field-hint" style={{ marginTop: 6, marginBottom: 16 }}>
              Enable or disable any section across the public portfolio. Disabled sections are gracefully removed from the page and navigation bars.
            </p>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 280px), 1fr))",
                gap: 12,
              }}
            >
              {[
                { key: "heroEnabled", label: "Home / Hero Section", desc: "Top introduction, title, and canvas framing" },
                { key: "aboutEnabled", label: "About Section", desc: "Bio, metrics row, degrees, and work experiences" },
                { key: "skillsEnabled", label: "Skills & Languages", desc: "Categorized engineering skill groups and pills" },
                { key: "projectsEnabled", label: "Projects Section", desc: "Main top 5 showcases and currently working ongoing builds" },
                { key: "resumeEnabled", label: "Resume / CV Section", desc: "Interactive CV document viewer and download actions" },
                { key: "gamesEnabled", label: "Mini-Games Section", desc: "Interactive 2048 & Signal Pairs memory challenge" },
                { key: "contactEnabled", label: "Get in Touch (Contact)", desc: "Contact inquiry form, direct email, and location" },
              ].map(({ key, label, desc }) => {
                const isChecked = (settings[key] ?? "true") !== "false";
                return (
                  <div
                    key={key}
                    style={{
                      padding: "12px 16px",
                      borderRadius: 12,
                      border: "1px solid var(--line)",
                      background: "rgba(255,255,255,0.02)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: 12,
                    }}
                  >
                    <div>
                      <strong style={{ color: "var(--white)", fontSize: 13, display: "block" }}>{label}</strong>
                      <span style={{ color: "var(--subtle)", fontSize: 11 }}>{desc}</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={(e) => handleChange(key, e.target.checked ? "true" : "false")}
                      style={{ width: 18, height: 18, accentColor: "var(--orange)", cursor: "pointer" }}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Education & Degrees Manager */}
          <div className="admin-card" style={{ gridColumn: "1 / -1" }}>
            <div className="admin-card-heading" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
              <div>
                <p className="section-kicker">Academic Credentials</p>
                <h3>Degrees &amp; Education Management</h3>
              </div>
              <button
                type="button"
                onClick={handleAddDegree}
                className="admin-small-button"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "8px 14px",
                  borderRadius: 8,
                  background: "rgba(var(--orange-rgb), 0.15)",
                  border: "1px solid var(--orange)",
                  color: "var(--white)",
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                <Plus size={14} /> Add Degree (e.g. M.Tech)
              </button>
            </div>
            <p className="field-hint" style={{ marginTop: 6, marginBottom: 16 }}>
              Add and manage your academic degrees. Toggle &apos;Show on Home&apos; to decide which degrees appear on the public portfolio. Adding M.Tech or other degrees automatically renders a dedicated credential card on the main page.
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {degrees.map((deg, index) => (
                <div key={deg.id} className="admin-degree-item-card">
                  {/* Top Bar with Reordering, Badge, Home Toggle, and Delete */}
                  <div className="admin-degree-topbar">
                    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                      <span className="admin-order-chip" style={{ fontWeight: 700, fontSize: 11, padding: "3px 8px" }}>
                        #{index + 1}
                      </span>
                      <div style={{ display: "inline-flex", gap: 4 }}>
                        <button
                          type="button"
                          onClick={() => handleMoveDegree(index, "up")}
                          disabled={index === 0}
                          title="Move Degree Up"
                          aria-label="Move degree up"
                          className="admin-reorder-btn"
                        >
                          <ChevronUp size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleMoveDegree(index, "down")}
                          disabled={index === degrees.length - 1}
                          title="Move Degree Down"
                          aria-label="Move degree down"
                          className="admin-reorder-btn"
                        >
                          <ChevronDown size={13} />
                        </button>
                      </div>
                      <span style={{ fontSize: 12, color: "var(--silver)", fontWeight: 600, marginLeft: 2 }}>
                        {deg.degree.trim() || `Credential #${index + 1}`}
                      </span>
                    </div>

                    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                      <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 12, color: "var(--silver)" }}>
                        <input
                          type="checkbox"
                          checked={deg.showOnHome}
                          onChange={(e) => handleUpdateDegree(deg.id, "showOnHome", e.target.checked)}
                          style={{ width: 16, height: 16, accentColor: "var(--orange)", cursor: "pointer" }}
                        />
                        <span>Show on Home</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handleDeleteDegree(deg.id)}
                        className="admin-small-button danger"
                        title="Remove degree"
                        aria-label="Remove degree"
                        style={{
                          width: 32,
                          height: 32,
                          padding: 0,
                          display: "grid",
                          placeItems: "center",
                          borderRadius: 8,
                          background: "rgba(239, 68, 68, 0.1)",
                          border: "1px solid rgba(239, 68, 68, 0.3)",
                          color: "#ef4444",
                          cursor: "pointer",
                        }}
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* Form fields: 2 columns on desktop, 1 column stacked on mobile */}
                  <div className="admin-degree-fields">
                    <div className="field" style={{ margin: 0 }}>
                      <label style={{ fontSize: 11 }}>Degree Title *</label>
                      <input
                        value={deg.degree}
                        onChange={(e) => handleUpdateDegree(deg.id, "degree", e.target.value)}
                        placeholder="e.g. B.Tech · Computer Science & Engineering"
                      />
                    </div>
                    <div className="field" style={{ margin: 0 }}>
                      <label style={{ fontSize: 11 }}>University / Institution *</label>
                      <input
                        value={deg.institution}
                        onChange={(e) => handleUpdateDegree(deg.id, "institution", e.target.value)}
                        placeholder="e.g. ICFAI University Tripura"
                      />
                    </div>
                    <div className="field" style={{ margin: 0 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4, flexWrap: "wrap", gap: 4 }}>
                        <label style={{ fontSize: 11, margin: 0 }}>University Webpage Link</label>
                        {deg.link ? (
                          <button
                            type="button"
                            onClick={() => handleUpdateDegree(deg.id, "link", "")}
                            style={{
                              background: "transparent",
                              border: "none",
                              color: "var(--orange)",
                              fontSize: 10,
                              cursor: "pointer",
                              padding: "0 2px",
                              textDecoration: "underline",
                            }}
                          >
                            Remove Link
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleUpdateDegree(deg.id, "link", "https://www.iutripura.edu.in/")}
                            style={{
                              background: "transparent",
                              border: "none",
                              color: "var(--orange)",
                              fontSize: 10,
                              cursor: "pointer",
                              padding: "0 2px",
                              textDecoration: "underline",
                            }}
                          >
                            Add ICFAI Link
                          </button>
                        )}
                      </div>
                      <input
                        value={deg.link}
                        onChange={(e) => handleUpdateDegree(deg.id, "link", e.target.value)}
                        placeholder="https://www.iutripura.edu.in/ (or leave blank)"
                      />
                    </div>
                    <div className="field" style={{ margin: 0 }}>
                      <label style={{ fontSize: 11 }}>Completion / Period</label>
                      <input
                        value={deg.period}
                        onChange={(e) => handleUpdateDegree(deg.id, "period", e.target.value)}
                        placeholder="e.g. 2023—expected 2027"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section Editorial Content & Lead Texts */}
          <div className="admin-card" style={{ gridColumn: "1 / -1" }}>
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Section Copywriting</p>
                <h3>Editorial Headings &amp; Section Descriptions</h3>
              </div>
            </div>
            <p className="field-hint" style={{ marginTop: 6, marginBottom: 18 }}>
              Directly edit all section headlines, subheads, and philosophy statements. Content automatically flows without overlapping.
            </p>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 320px), 1fr))",
                gap: 18,
              }}
            >
              {/* About Section Texts */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  About Section
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.aboutTitle ?? "Engineering with purpose."}
                    onChange={(e) => handleChange("aboutTitle", e.target.value)}
                    placeholder="Engineering with purpose."
                  />
                </div>
                <div className="field">
                  <label>Bio Summary (under Heading)</label>
                  <textarea
                    rows={2}
                    value={
                      settings.aboutBio ??
                      "B.Tech Computer Science and Engineering undergraduate at ICFAI University Tripura. I work across AI/ML, full-stack software, mobile apps, and cybersecurity."
                    }
                    onChange={(e) => handleChange("aboutBio", e.target.value)}
                  />
                </div>
                <div className="field">
                  <label>Lead Engineering Philosophy (beside Experience)</label>
                  <textarea
                    rows={3}
                    value={
                      settings.aboutLead ??
                      "I turn complex requirements into clear, reliable software. I enjoy exploring the details, connecting the right tools, and shaping each idea into something people can use."
                    }
                    onChange={(e) => handleChange("aboutLead", e.target.value)}
                  />
                </div>
              </div>

              {/* Skills Section Texts */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  Technical Skills Section
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.skillsTitle ?? "A broad stack. A builder's mindset."}
                    onChange={(e) => handleChange("skillsTitle", e.target.value)}
                    placeholder="A broad stack. A builder's mindset."
                  />
                </div>
                <div className="field">
                  <label>Aside Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.skillsSubtitle ??
                      "Tools are only useful when they fit the job. I keep learning across product engineering, intelligent systems, and secure software."
                    }
                    onChange={(e) => handleChange("skillsSubtitle", e.target.value)}
                  />
                </div>
              </div>

              {/* Main Projects Showcase */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  Main Projects Showcase
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.projectsTitle ?? "Real problems. Useful software."}
                    onChange={(e) => handleChange("projectsTitle", e.target.value)}
                    placeholder="Real problems. Useful software."
                  />
                </div>
                <div className="field">
                  <label>Aside Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.projectsSubtitle ??
                      "A curated cross-section of AI, cybersecurity, systems, and full-stack engineering."
                    }
                    onChange={(e) => handleChange("projectsSubtitle", e.target.value)}
                  />
                </div>
              </div>

              {/* Currently Working Subsection */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  Currently Working On (Ongoing Subsection)
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Subsection Heading</label>
                  <input
                    value={settings.ongoingTitle ?? "Currently working on. Next-generation builds."}
                    onChange={(e) => handleChange("ongoingTitle", e.target.value)}
                    placeholder="Currently working on. Next-generation builds."
                  />
                </div>
                <div className="field">
                  <label>Subsection Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.ongoingSubtitle ??
                      "Projects undergoing active engineering and architectural iteration. Once completed, they are deployed directly to the main portfolio section."
                    }
                    onChange={(e) => handleChange("ongoingSubtitle", e.target.value)}
                  />
                </div>
              </div>

              {/* Resume Section Texts */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  CV / Resume Section
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.resumeTitle ?? "Experience in the details."}
                    onChange={(e) => handleChange("resumeTitle", e.target.value)}
                    placeholder="Experience in the details."
                  />
                </div>
                <div className="field">
                  <label>Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.resumeSubtitle ??
                      "Education, internships, technical work, and the projects behind this portfolio—all in one place."
                    }
                    onChange={(e) => handleChange("resumeSubtitle", e.target.value)}
                  />
                </div>

                {/* CV Watermark Controls */}
                <div id="sec-watermark" style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <strong style={{ fontSize: 11, color: "var(--soft-white)" }}>CV Watermark Overlay</strong>
                    <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 11, color: "var(--silver)" }}>
                      <input
                        type="checkbox"
                        checked={settings.cvWatermarkEnabled !== "false"}
                        onChange={(e) => handleChange("cvWatermarkEnabled", e.target.checked ? "true" : "false")}
                        style={{ width: 14, height: 14, accentColor: "var(--orange)", cursor: "pointer" }}
                      />
                      <span>{settings.cvWatermarkEnabled !== "false" ? "Watermark Active" : "Watermark Removed"}</span>
                    </label>
                  </div>
                  {settings.cvWatermarkEnabled !== "false" && (
                    <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: 10 }}>
                      <div className="field" style={{ margin: 0 }}>
                        <label style={{ fontSize: 10 }}>Watermark Text</label>
                        <input
                          style={{ fontSize: 11 }}
                          value={settings.cvWatermarkText ?? "bijoy-sarkar-portfolio"}
                          onChange={(e) => handleChange("cvWatermarkText", e.target.value)}
                          placeholder="bijoy-sarkar-portfolio"
                        />
                      </div>
                      <div className="field" style={{ margin: 0 }}>
                        <label style={{ fontSize: 10 }}>Opacity</label>
                        <select
                          style={{ fontSize: 11 }}
                          value={settings.cvWatermarkOpacity ?? "0.085"}
                          onChange={(e) => handleChange("cvWatermarkOpacity", e.target.value)}
                        >
                          <option value="0.04">Subtle (4%)</option>
                          <option value="0.085">Default (8.5%)</option>
                          <option value="0.15">Medium (15%)</option>
                          <option value="0.25">Prominent (25%)</option>
                        </select>
                      </div>
                      <div className="field" style={{ margin: 0 }}>
                        <label style={{ fontSize: 10 }}>Angle</label>
                        <select
                          style={{ fontSize: 11 }}
                          value={settings.cvWatermarkAngle ?? "-22"}
                          onChange={(e) => handleChange("cvWatermarkAngle", e.target.value)}
                        >
                          <option value="-22">-22°</option>
                          <option value="-45">-45°</option>
                          <option value="0">0°</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Games Section Texts */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  Mini-Games Section
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.gamesTitle ?? "Take a break. Play a little."}
                    onChange={(e) => handleChange("gamesTitle", e.target.value)}
                    placeholder="Take a break. Play a little."
                  />
                </div>
                <div className="field">
                  <label>Aside Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.gamesSubtitle ??
                      "Two quick games, built for the keyboard and touch. Come back whenever you are ready."
                    }
                    onChange={(e) => handleChange("gamesSubtitle", e.target.value)}
                  />
                </div>
              </div>

              {/* Contact Section Texts */}
              <div style={{ padding: 16, borderRadius: 12, border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}>
                <strong style={{ color: "var(--orange)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                  Contact Section
                </strong>
                <div className="field" style={{ marginTop: 10 }}>
                  <label>Section Heading</label>
                  <input
                    value={settings.contactTitle ?? "Have a problem worth solving?"}
                    onChange={(e) => handleChange("contactTitle", e.target.value)}
                    placeholder="Have a problem worth solving?"
                  />
                </div>
                <div className="field">
                  <label>Description</label>
                  <textarea
                    rows={3}
                    value={
                      settings.contactSubtitle ??
                      "For software roles, AI/ML work, or a project idea, send a note and tell me what you have in mind."
                    }
                    onChange={(e) => handleChange("contactSubtitle", e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Identity & Hero Section */}
          <div className="admin-card">
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Hero Identity</p>
                <h3>Headline &amp; Bio Information</h3>
              </div>
            </div>

            <div className="field" style={{ marginTop: 14 }}>
              <label htmlFor="setting-heroTitle">Primary Hero Title</label>
              <input
                id="setting-heroTitle"
                value={settings.heroTitle ?? "Software Engineer & AI Developer"}
                onChange={(e) => handleChange("heroTitle", e.target.value)}
                placeholder="Software Engineer & AI Developer"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-heroSubhead">Hero Subheadline</label>
              <input
                id="setting-heroSubhead"
                value={settings.heroSubhead ?? "Building intelligent systems and full-stack solutions."}
                onChange={(e) => handleChange("heroSubhead", e.target.value)}
                placeholder="Building intelligent systems and full-stack solutions."
              />
            </div>

            <div className="field">
              <label htmlFor="setting-heroBio">Hero Bio / Description</label>
              <textarea
                id="setting-heroBio"
                rows={3}
                value={
                  settings.heroBio ??
                  "Computer Science undergraduate focused on AI/ML, secure software, and useful digital products."
                }
                onChange={(e) => handleChange("heroBio", e.target.value)}
              />
            </div>

            <div className="field">
              <label htmlFor="setting-status">Current Status Pill</label>
              <input
                id="setting-status"
                value={settings.status ?? "Open to opportunities"}
                onChange={(e) => handleChange("status", e.target.value)}
              />
            </div>
          </div>

          {/* Contact, Inboxes & Addresses */}
          <div className="admin-card">
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Availability &amp; Inboxes</p>
                <h3>Contact &amp; Delivery Settings</h3>
              </div>
            </div>

            <div className="field" style={{ marginTop: 14 }}>
              <label htmlFor="setting-contactEmail">Public Display Email</label>
              <input
                id="setting-contactEmail"
                type="email"
                value={settings.contactEmail ?? "bijoysarkar7252@gmail.com"}
                onChange={(e) => handleChange("contactEmail", e.target.value)}
              />
              <span className="field-hint">Publicly displayed email on Contact section, Hero, and Footer.</span>
            </div>

            <div className="field">
              <label htmlFor="setting-contactRecipientEmail">Contact Form Destination Inbox</label>
              <input
                id="setting-contactRecipientEmail"
                type="email"
                placeholder="bijoysarkar7252@gmail.com"
                value={settings.contactRecipientEmail ?? "bijoysarkar7252@gmail.com"}
                onChange={(e) => handleChange("contactRecipientEmail", e.target.value)}
              />
              <span className="field-hint">Where visitor messages sent through the Contact Us form will be delivered.</span>
            </div>

            <div className="field">
              <label htmlFor="setting-location">Permanent / Primary Address</label>
              <input
                id="setting-location"
                value={settings.location ?? "Agartala, Tripura, India"}
                onChange={(e) => handleChange("location", e.target.value)}
              />
              <span className="field-hint">Home city/state/country (default: Agartala, Tripura, India).</span>
            </div>

            <div className="field">
              <label htmlFor="setting-locationMapUrl">Permanent Address Google Maps Link</label>
              <input
                id="setting-locationMapUrl"
                value={settings.locationMapUrl ?? "https://maps.google.com/?q=Agartala,+Tripura,+India"}
                onChange={(e) => handleChange("locationMapUrl", e.target.value)}
                placeholder="https://maps.google.com/?q=Agartala,+Tripura,+India"
              />
              <span className="field-hint">Link opened when visitors click on the permanent address.</span>
            </div>

            <div className="field">
              <label htmlFor="setting-currentLocation">Current / Working Address (Optional)</label>
              <input
                id="setting-currentLocation"
                value={settings.currentLocation ?? ""}
                onChange={(e) => handleChange("currentLocation", e.target.value)}
                placeholder="e.g. Bengaluru, Karnataka, India (or leave blank)"
              />
              <span className="field-hint">For future relocations or internships.</span>
            </div>

            <div className="field">
              <label htmlFor="setting-currentLocationMapUrl">Current Address Google Maps Link (Optional)</label>
              <input
                id="setting-currentLocationMapUrl"
                value={settings.currentLocationMapUrl ?? ""}
                onChange={(e) => handleChange("currentLocationMapUrl", e.target.value)}
                placeholder="e.g. https://maps.google.com/?q=Bengaluru,+Karnataka,+India"
              />
              <span className="field-hint">Google Maps link for current address.</span>
            </div>

            <div className="field">
              <label>Address Display Mode</label>
              <select
                value={settings.displayAddressMode ?? "primary"}
                onChange={(e) => handleChange("displayAddressMode", e.target.value)}
              >
                <option value="primary">Show Primary Address Only (Agartala, Tripura, India)</option>
                <option value="current">Show Current Address Only</option>
                <option value="both">Show Both (Primary &amp; Current)</option>
              </select>
            </div>

            <div className="field" style={{ gridColumn: "1 / -1" }}>
              <label htmlFor="setting-googleSheetsWebhookUrl" style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Sheet size={14} style={{ color: "#34a853" }} />
                <span>Google Sheets Webhook URL</span>
              </label>
              <input
                id="setting-googleSheetsWebhookUrl"
                placeholder="https://script.google.com/macros/s/.../exec"
                value={settings.googleSheetsWebhookUrl ?? ""}
                onChange={(e) => handleChange("googleSheetsWebhookUrl", e.target.value)}
              />
              <span className="field-hint">
                Deployed Google Apps Script Web App URL. Contact submissions automatically sync here.
              </span>
            </div>
          </div>

          {/* Social Media Links */}
          <div className="admin-card">
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Social Media</p>
                <h3>Online Profiles &amp; Handles</h3>
              </div>
            </div>

            <div className="field" style={{ marginTop: 14 }}>
              <label htmlFor="setting-githubUrl">GitHub Profile URL</label>
              <input
                id="setting-githubUrl"
                value={settings.githubUrl ?? "https://github.com/BijoySarkar19"}
                onChange={(e) => handleChange("githubUrl", e.target.value)}
                placeholder="https://github.com/BijoySarkar19"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-linkedinUrl">LinkedIn Profile URL</label>
              <input
                id="setting-linkedinUrl"
                value={settings.linkedinUrl ?? "https://www.linkedin.com/in/bijoysarkar19"}
                onChange={(e) => handleChange("linkedinUrl", e.target.value)}
                placeholder="https://www.linkedin.com/in/bijoysarkar19"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-twitterUrl">X / Twitter Profile URL</label>
              <input
                id="setting-twitterUrl"
                value={settings.twitterUrl ?? "https://x.com/bijoyy_19"}
                onChange={(e) => handleChange("twitterUrl", e.target.value)}
                placeholder="https://x.com/bijoyy_19"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-instagramUrl">Instagram Profile URL</label>
              <input
                id="setting-instagramUrl"
                value={settings.instagramUrl ?? "https://www.instagram.com/bijoyysarkarr?obrf=dW1zenpraWt3eGI="}
                onChange={(e) => handleChange("instagramUrl", e.target.value)}
                placeholder="https://www.instagram.com/username"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-facebookUrl">Facebook Profile URL</label>
              <input
                id="setting-facebookUrl"
                value={settings.facebookUrl ?? "https://www.facebook.com/share/1Cs44JBwnk/"}
                onChange={(e) => handleChange("facebookUrl", e.target.value)}
                placeholder="https://www.facebook.com/..."
              />
            </div>

            <div className="field">
              <label htmlFor="setting-youtubeUrl">YouTube Channel URL</label>
              <input
                id="setting-youtubeUrl"
                value={settings.youtubeUrl ?? ""}
                onChange={(e) => handleChange("youtubeUrl", e.target.value)}
                placeholder="https://youtube.com/@channel (Optional)"
              />
            </div>

            <div className="field">
              <label htmlFor="setting-discordUrl">Discord Profile / Invite URL</label>
              <input
                id="setting-discordUrl"
                value={settings.discordUrl ?? ""}
                onChange={(e) => handleChange("discordUrl", e.target.value)}
                placeholder="https://discord.gg/... (Optional)"
              />
            </div>
          </div>

          {/* Project Artwork & Gallery Configuration */}
          <div className="admin-card">
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Projects &amp; Gallery Defaults</p>
                <h3>Project Artwork &amp; Default Image Settings</h3>
              </div>
            </div>

            {/* Default Ongoing Project Image */}
            <div style={{ marginTop: 16 }}>
              <label style={{ display: "block", color: "var(--soft-white)", fontSize: 13, marginBottom: 6, fontWeight: 600 }}>
                Default Artwork for Currently Doing / Active Development Projects
              </label>
              <p style={{ margin: "0 0 14px", fontSize: 12, color: "var(--muted)" }}>
                This image is automatically used as the default cover for ongoing projects. Full-box zero-black-parts white background and alternative themes are selectable below.
              </p>

              <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap", marginBottom: 16 }}>
                {/* Active Artwork Thumbnail Preview Box */}
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 145, flexShrink: 0 }}>
                  <div
                    style={{
                      width: 145,
                      height: 190,
                      position: "relative",
                      borderRadius: 12,
                      overflow: "hidden",
                      border: settings.ongoingDefaultImage ? "2px solid var(--orange)" : "2px dashed var(--line)",
                      boxShadow: settings.ongoingDefaultImage ? "0 8px 24px rgba(var(--orange-rgb), 0.25)" : "none",
                      background: settings.ongoingDefaultImage?.includes("fullbleed") ? "var(--orange)" : "#ffffff",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {settings.ongoingDefaultImage ? (
                      <>
                        <Image
                          src={settings.ongoingDefaultImage}
                          alt="Current Default Ongoing Artwork"
                          fill
                          unoptimized
                          style={{ objectFit: "cover" }}
                        />
                        <span
                          style={{
                            position: "absolute",
                            bottom: 6,
                            left: 6,
                            background: "rgba(0,0,0,0.85)",
                            color: "var(--orange)",
                            fontSize: "9px",
                            padding: "2px 6px",
                            borderRadius: 4,
                            fontWeight: 700,
                            letterSpacing: "0.05em",
                          }}
                        >
                          ACTIVE DEFAULT
                        </span>
                      </>
                    ) : (
                      <div style={{ padding: 12, textAlign: "center", color: "var(--muted)" }}>
                        <EyeOff size={26} style={{ opacity: 0.6, marginBottom: 6 }} />
                        <p style={{ margin: 0, fontSize: 11, fontWeight: 700, color: "var(--white)" }}>No Photo Set</p>
                        <p style={{ margin: "4px 0 0", fontSize: 9, opacity: 0.8 }}>Will show &quot;Upcoming on his way&quot;</p>
                      </div>
                    )}
                  </div>

                  {/* Remove Photo or Restore Default Button */}
                  <div style={{ width: "100%", marginTop: 8 }}>
                    {settings.ongoingDefaultImage ? (
                      <button
                        type="button"
                        onClick={handleRemovePhoto}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: 5,
                          width: "100%",
                          padding: "6px 10px",
                          borderRadius: 8,
                          border: "1px solid rgba(239, 68, 68, 0.4)",
                          background: "rgba(239, 68, 68, 0.08)",
                          color: "#ef4444",
                          fontSize: 11,
                          fontWeight: 600,
                          cursor: "pointer",
                          transition: "all 180ms ease",
                        }}
                        title="Remove current default photo (clears image from ongoing projects)"
                      >
                        <Trash2 size={12} /> Remove Photo
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          handleChange(
                            "ongoingDefaultImage",
                            getMatchingOngoingCover(settings.themeAccent || "#ff5e2c", false)
                          )
                        }
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: 5,
                          width: "100%",
                          padding: "6px 10px",
                          borderRadius: 8,
                          border: "1px solid var(--orange)",
                          background: "rgba(var(--orange-rgb), 0.12)",
                          color: "var(--orange)",
                          fontSize: 11,
                          fontWeight: 600,
                          cursor: "pointer",
                          transition: "all 180ms ease",
                        }}
                      >
                        <RotateCcw size={12} /> Restore Default
                      </button>
                    )}
                  </div>
                </div>

                {/* Artwork Controls: Styles, Presets, Custom Upload */}
                <div style={{ flex: 1, minWidth: 280 }}>
                  <label style={{ display: "block", color: "var(--soft-white)", fontSize: 12, marginBottom: 8, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                    Choose Artwork Style (Both change dynamically with website color)
                  </label>

                  {/* The Two Photo Options */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10, marginBottom: 14 }}>
                    {/* Option 1: White Background Style */}
                    {(() => {
                      const isWhiteActive = Boolean(
                        settings.ongoingDefaultImage &&
                          !settings.ongoingDefaultImage.includes("fullbleed") &&
                          (settings.ongoingDefaultImage.includes("ongoing-project-cover") ||
                            settings.ongoingDefaultImage.includes("ongoing-coder"))
                      );
                      return (
                        <button
                          type="button"
                          onClick={() =>
                            handleChange(
                              "ongoingDefaultImage",
                              getMatchingOngoingCover(settings.themeAccent || "#ff5e2c", false)
                            )
                          }
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "flex-start",
                            gap: 4,
                            padding: "10px 14px",
                            borderRadius: 10,
                            border: isWhiteActive ? "2px solid var(--orange)" : "1px solid var(--line)",
                            background: isWhiteActive
                              ? "rgba(var(--orange-rgb), 0.15)"
                              : "var(--panel, rgba(255, 255, 255, 0.04))",
                            cursor: "pointer",
                            textAlign: "left",
                            transition: "all 180ms ease",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}>
                            <span style={{ fontSize: 12, fontWeight: 700, color: isWhiteActive ? "var(--orange)" : "var(--white)" }}>
                              ☀️ Option 1: White Background
                            </span>
                            {isWhiteActive && <Check size={14} style={{ color: "var(--orange)" }} />}
                          </div>
                          <span style={{ fontSize: 11, color: "var(--muted)" }}>
                            Clean white box, coder silhouette rendered in website accent
                          </span>
                        </button>
                      );
                    })()}

                    {/* Option 2: Full-Bleed Theme Background Style */}
                    {(() => {
                      const isFullBleedActive = Boolean(settings.ongoingDefaultImage?.includes("fullbleed"));
                      return (
                        <button
                          type="button"
                          onClick={() =>
                            handleChange(
                              "ongoingDefaultImage",
                              getMatchingOngoingCover(settings.themeAccent || "#ff5e2c", true)
                            )
                          }
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "flex-start",
                            gap: 4,
                            padding: "10px 14px",
                            borderRadius: 10,
                            border: isFullBleedActive ? "2px solid var(--orange)" : "1px solid var(--line)",
                            background: isFullBleedActive
                              ? "rgba(var(--orange-rgb), 0.15)"
                              : "var(--panel, rgba(255, 255, 255, 0.04))",
                            cursor: "pointer",
                            textAlign: "left",
                            transition: "all 180ms ease",
                          }}
                        >
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}>
                            <span style={{ fontSize: 12, fontWeight: 700, color: isFullBleedActive ? "var(--orange)" : "var(--white)" }}>
                              ⚡ Option 2: Full-Bleed Theme
                            </span>
                            {isFullBleedActive && <Check size={14} style={{ color: "var(--orange)" }} />}
                          </div>
                          <span style={{ fontSize: 11, color: "var(--muted)" }}>
                            Full website color background with dark obsidian coder
                          </span>
                        </button>
                      );
                    })()}
                  </div>

                  {/* Preset Color Variations for Selected Style */}
                  <div style={{ marginBottom: 14 }}>
                    <span style={{ display: "block", fontSize: 11, fontWeight: 600, color: "var(--muted)", marginBottom: 8 }}>
                      Select Preset Color Theme:
                    </span>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {[
                        { name: "Neon Violet", key: "violet", hex: "#9d4edd" },
                        { name: "Cyber Orange", key: "orange", hex: "#ff5e2c" },
                        { name: "Electric Blue", key: "blue", hex: "#00b4d8" },
                        { name: "Matrix Emerald", key: "emerald", hex: "#00f5d4" },
                        { name: "Crimson Red", key: "red", hex: "#e63946" },
                      ].map((c) => {
                        const isFullBleed = Boolean(settings.ongoingDefaultImage?.includes("fullbleed"));
                        const targetFile = isFullBleed
                          ? `/images/ongoing-project-cover-fullbleed-${c.key}.webp`
                          : `/images/ongoing-project-cover-${c.key}.webp`;
                        const isSelected = settings.ongoingDefaultImage === targetFile;

                        return (
                          <button
                            key={c.key}
                            type="button"
                            onClick={() => handleChange("ongoingDefaultImage", targetFile)}
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 6,
                              padding: "6px 12px",
                              borderRadius: 8,
                              border: isSelected ? "2px solid var(--orange)" : "1px solid var(--line)",
                              background: isSelected
                                ? "rgba(var(--orange-rgb), 0.16)"
                                : "var(--panel, rgba(255, 255, 255, 0.04))",
                              color: isSelected ? "var(--orange)" : "var(--soft-white)",
                              fontSize: 11,
                              fontWeight: 600,
                              cursor: "pointer",
                              transition: "all 180ms ease",
                            }}
                          >
                            <span
                              style={{
                                width: 9,
                                height: 9,
                                borderRadius: "50%",
                                background: c.hex,
                                boxShadow: isSelected ? `0 0 8px ${c.hex}` : "none",
                              }}
                            />
                            <span>{c.name}</span>
                            {isSelected && <Check size={11} style={{ color: "var(--orange)" }} />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Custom Photo Upload & Path Input */}
                  <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8, flexWrap: "wrap", gap: 8 }}>
                      <span style={{ fontSize: 12, fontWeight: 600, color: "var(--soft-white)" }}>
                        Custom Photo (Upload or URL with Live Preview)
                      </span>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingArtwork}
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 6,
                          padding: "6px 14px",
                          borderRadius: 8,
                          border: "1px solid var(--orange)",
                          background: "rgba(var(--orange-rgb), 0.12)",
                          color: "var(--orange)",
                          fontSize: 11,
                          fontWeight: 700,
                          cursor: "pointer",
                        }}
                      >
                        <Upload size={12} /> {uploadingArtwork ? "Uploading..." : "Upload Custom Photo"}
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif"
                        style={{ display: "none" }}
                        onChange={handleCustomPhotoUpload}
                      />
                    </div>

                    <div className="field" style={{ margin: 0 }}>
                      <input
                        id="setting-ongoingDefaultImage"
                        value={settings.ongoingDefaultImage ?? ""}
                        onChange={(e) => handleChange("ongoingDefaultImage", e.target.value)}
                        placeholder="Upload an image or enter /images/... or https://..."
                        style={{ fontFamily: "monospace", fontSize: 13, color: "var(--white)" }}
                      />
                      <span className="field-hint">
                        Supports local device uploads, paths in public/, or any HTTPS image URL. Preview updates live as you type.
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Default Image Count for Finished Projects */}
            <div style={{ marginTop: 20, paddingTop: 16, borderTop: "1px solid var(--line)" }}>
              <label style={{ display: "block", color: "var(--soft-white)", fontSize: 13, marginBottom: 6, fontWeight: 600 }}>
                Default Number Count of Images for Projects (e.g. 3 to 4 or 3 to 2)
              </label>
              <p style={{ margin: "0 0 12px", fontSize: 12, color: "var(--muted)" }}>
                When creating a new project, this sets how many image input slots are created by default. You can always add or remove slots on any project.
              </p>

              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                {[1, 2, 3, 4, 5, 6].map((count) => {
                  const isSelected = (settings.defaultProjectImageCount ?? "3") === String(count);
                  return (
                    <button
                      key={count}
                      type="button"
                      onClick={() => handleChange("defaultProjectImageCount", String(count))}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "7px 14px",
                        borderRadius: 8,
                        border: isSelected ? "2px solid var(--orange)" : "1px solid var(--line)",
                        background: isSelected
                          ? "rgba(var(--orange-rgb), 0.18)"
                          : "var(--panel, rgba(255, 255, 255, 0.04))",
                        color: isSelected ? "var(--orange)" : "var(--soft-white)",
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: "pointer",
                        transition: "all 180ms ease",
                      }}
                    >
                      {count} {count === 1 ? "Image" : "Images"}
                      {isSelected && <Check size={12} />}
                    </button>
                  );
                })}

                <div style={{ display: "inline-flex", alignItems: "center", gap: 8, marginLeft: 10 }}>
                  <span style={{ fontSize: 12, color: "var(--muted)", fontWeight: 600 }}>Custom:</span>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={settings.defaultProjectImageCount ?? "3"}
                    onChange={(e) => handleChange("defaultProjectImageCount", e.target.value)}
                    style={{
                      width: 65,
                      padding: "6px 8px",
                      fontSize: 13,
                      textAlign: "center",
                      borderRadius: 8,
                      border: "1px solid var(--line)",
                      background: "var(--surface)",
                      color: "var(--soft-white)",
                      fontWeight: 700,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Theme Accent & Display Mode */}
          <div className="admin-card">
            <div className="admin-card-heading">
              <div>
                <p className="section-kicker">Aesthetics &amp; Colors</p>
                <h3>Accent Theme &amp; Display Engine</h3>
              </div>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={{ display: "block", color: "var(--soft-white)", fontSize: 13, marginBottom: 8, fontWeight: 600 }}>
                Display Theme Mode
              </label>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
                {[
                  { mode: "dark", label: "Dark Mode (Default)", icon: Moon },
                  { mode: "light", label: "Light Mode", icon: Sun },
                ].map(({ mode, label, icon: Icon }) => {
                  const isSelected = (settings.themeMode ?? "dark") === mode;
                  return (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => handleChange("themeMode", mode)}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        padding: "8px 16px",
                        borderRadius: 10,
                        border: isSelected ? "2px solid var(--orange)" : "1px solid var(--line)",
                        background: isSelected ? "rgba(var(--orange-rgb), 0.12)" : "rgba(255, 255, 255, 0.03)",
                        cursor: "pointer",
                        color: isSelected ? "var(--orange)" : "var(--soft-white)",
                        fontSize: 12,
                        fontWeight: 600,
                      }}
                    >
                      <Icon size={14} style={{ color: isSelected ? "var(--orange)" : "var(--silver)" }} />
                      <span>{label}</span>
                      {isSelected && <Check size={12} style={{ color: "var(--orange)", marginLeft: 2 }} />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div style={{ marginTop: 20 }}>
              <label style={{ display: "block", color: "var(--soft-white)", fontSize: 13, marginBottom: 8, fontWeight: 600 }}>
                Theme Accent Color
              </label>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                {ACCENT_PRESETS.map((preset) => {
                  const isSelected = (settings.themeAccent ?? "#ff5e2c").toLowerCase() === preset.hex.toLowerCase();
                  return (
                    <button
                      key={preset.hex}
                      type="button"
                      onClick={() => handleChange("themeAccent", preset.hex)}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "6px 12px",
                        borderRadius: 8,
                        border: isSelected ? `2px solid ${preset.hex}` : "1px solid var(--line)",
                        background: isSelected ? "rgba(255, 255, 255, 0.08)" : "rgba(255, 255, 255, 0.03)",
                        cursor: "pointer",
                        color: isSelected ? "var(--orange)" : "var(--soft-white)",
                        fontSize: 11,
                      }}
                    >
                      <span
                        style={{
                          width: 12,
                          height: 12,
                          borderRadius: "50%",
                          background: preset.hex,
                          boxShadow: `0 0 6px ${preset.hex}`,
                        }}
                      />
                      <span>{preset.name}</span>
                      {isSelected && <Check size={11} style={{ color: preset.hex }} />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div style={{ marginTop: 28, display: "flex", justifyContent: "flex-end" }}>
              <button className="button" type="submit" disabled={loading} style={{ minWidth: 160 }}>
                <Save size={14} /> {loading ? "Saving Settings..." : "Save Settings"}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
