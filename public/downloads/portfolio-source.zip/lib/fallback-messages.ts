// Auto-generated fallback contact messages from Google Sheets
// Synchronizes all rows (Rows 2 to 25 + Direct) ensuring 1:1 parity with Google Sheets

export interface FallbackContactMessage {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  message: string;
  submittedAtIST: string;
  ipAddress?: string | null;
  status: string;
  googleSynced: boolean;
  notes?: string | null;
  createdAt: string;
}

export const FALLBACK_CONTACT_MESSAGES: FallbackContactMessage[] = [
  {
    "id": "sheet-row-2",
    "name": "Verification Bot",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "Not provided",
    "message": "Testing Google Sheet direct append and Gmail alert.",
    "submittedAtIST": "31 Oct 2026, 02:12:00 am IST",
    "ipAddress": "127.0.0.1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.269Z"
  },
  {
    "id": "sheet-row-3",
    "name": "Bijoy Self",
    "email": "bijoy.the.sarkar@gmail.com",
    "phone": "Not provided",
    "message": "Hi how are you ? This is a test message to ensure contact service functions properly.",
    "submittedAtIST": "31 Oct 2026, 12:37:47 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-4",
    "name": "Bijoy Self",
    "email": "bijoy.the.sarkar@gmail.com",
    "phone": "Not provided",
    "message": "Hi how are you ?",
    "submittedAtIST": "31 Oct 2026, 12:42:38 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-5",
    "name": "Inquiry (Sheet Row 5)",
    "email": "Not provided",
    "phone": "Not provided",
    "message": "Direct spreadsheet inquiry recorded on Google Sheets (Row 5).",
    "submittedAtIST": "Sat Oct 31 2026 03:59:23 GMT+0530 (India Standard Time)",
    "ipAddress": "Unknown",
    "status": "UNREAD",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-6",
    "name": "yupp",
    "email": "gg@yahoo.com",
    "phone": "Not provided",
    "message": "Its me self for testing",
    "submittedAtIST": "31 Oct 2026, 04:54:47 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-7",
    "name": "cdv",
    "email": "vdv@gmail.com",
    "phone": "Not provided",
    "message": "TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST",
    "submittedAtIST": "31 Oct 2026, 04:58:27 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-8",
    "name": "CDV",
    "email": "DWD@gmail.com",
    "phone": "Not provided",
    "message": "TEST TEST TEST TEST TEST  125",
    "submittedAtIST": "31 Oct 2026, 04:59:55 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-9",
    "name": "Test Phone Fix",
    "email": "test@example.com",
    "phone": "+91 9158554458",
    "message": "Testing phone quote fix in Google Sheets",
    "submittedAtIST": "31 Oct 2026, 05:05:00 am IST",
    "ipAddress": "127.0.0.1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-10",
    "name": "Webhook Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9158554458",
    "message": "Testing automatic phone text formatting with Version 3 deployment",
    "submittedAtIST": "31 Oct 2026, 05:13:00 am IST",
    "ipAddress": "127.0.0.1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-11",
    "name": "Bijoy Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "9876543210",
    "message": "Testing zero-error contact form and direct mail delivery from Kubernetes cluster!",
    "submittedAtIST": "21 Nov 2026, 02:36:45 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-12",
    "name": "Bijoy Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Zero error verification of direct inbox mail and Google Sheets sync inside Kubernetes cluster!",
    "submittedAtIST": "21 Nov 2026, 02:39:57 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-13",
    "name": "Bijoy Sarkar Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Testing contact form end-to-end to verify zero errors and direct delivery to inbox.",
    "submittedAtIST": "21 Nov 2026, 02:44:41 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-14",
    "name": "Webhook Live Test",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Testing direct Google Apps Script Webhook dispatch and Gmail alert!",
    "submittedAtIST": "21 Nov 2026, 02:56:00 am IST",
    "ipAddress": "Unknown",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-15",
    "name": "Node Fetch Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Testing native node fetch redirect behavior with Google Apps Script Webhook.",
    "submittedAtIST": "21 Nov 2026, 03:00:00 am IST",
    "ipAddress": "Unknown",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-16",
    "name": "Bijoy End-to-End Test",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Testing automatic Google Sheets append and instant Gmail alert dispatch.",
    "submittedAtIST": "21 Nov 2026, 03:01:09 am IST",
    "ipAddress": "::1",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-17",
    "name": "Bijoy Post-Fix Verification",
    "email": "bijoysarkar7252@gmail.com",
    "phone": "+91 9876543210",
    "message": "Verifying live Vercel deployment with hardcoded Google Sheets Webhook fallback and instant alert.",
    "submittedAtIST": "21 Nov 2026, 03:06:56 am IST",
    "ipAddress": "106.222.224.158",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-18",
    "name": "ho",
    "email": "ho@gh.com",
    "phone": "+91 9863475856",
    "message": "do you knoe me .",
    "submittedAtIST": "21 Nov 2026, 03:09:53 am IST",
    "ipAddress": "106.222.224.158",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-19",
    "name": "ho",
    "email": "ho@ho.com",
    "phone": "+91 9863447546",
    "message": "do you know me .",
    "submittedAtIST": "21 Nov 2026, 03:10:38 am IST",
    "ipAddress": "106.222.224.158",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-20",
    "name": "Inquiry (Sheet Row 20)",
    "email": "Not provided",
    "phone": "Not provided",
    "message": "Direct spreadsheet inquiry recorded on Google Sheets (Row 20).",
    "submittedAtIST": "Sat Nov 21 2026 03:13:57 GMT+0530 (India Standard Time)",
    "ipAddress": "Unknown",
    "status": "UNREAD",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-21",
    "name": "yupp",
    "email": "yupp@yu.com",
    "phone": "Not provided",
    "message": "Bhc ghe c hu j",
    "submittedAtIST": "21 Nov 2026, 12:04:10 pm IST",
    "ipAddress": "106.222.226.72",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-22",
    "name": "bjbj",
    "email": "hdjv@gdb.com",
    "phone": "Not provided",
    "message": "ddvnjed uch ef 8 e u8e",
    "submittedAtIST": "21 Nov 2026, 12:04:49 pm IST",
    "ipAddress": "106.222.226.72",
    "status": "READ",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-23",
    "name": "yu",
    "email": "hdsg@gmi.com",
    "phone": "+91 6005151521",
    "message": "vdvd hcided Hi whou are you",
    "submittedAtIST": "22 Nov 2026, 12:27:02 am IST",
    "ipAddress": "106.222.226.72",
    "status": "REPLIED",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-24",
    "name": "Bij",
    "email": "bij@bij.com",
    "phone": "+91 9863476586",
    "message": "Hi how are you .",
    "submittedAtIST": "Tuesday, 24 Nov 2026, 03:56:49 pm IST",
    "ipAddress": "49.42.100.95",
    "status": "UNREAD",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "sheet-row-25",
    "name": "Speed Verification",
    "email": "bijoy.test@example.com",
    "phone": "+91 9876543210",
    "message": "Testing instant sub-second contact form dispatch after optimization.",
    "submittedAtIST": "Tuesday, 24 Nov 2026, 05:05:54 pm IST",
    "ipAddress": "::1",
    "status": "UNREAD",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-25T06:35:33.270Z"
  },
  {
    "id": "cmwumc9qc0000bwhjwnchmhk6",
    "name": "Speed Verification",
    "email": "bijoy.test@example.com",
    "phone": "+91 9876543210",
    "message": "Testing instant sub-second contact form dispatch after optimization.",
    "submittedAtIST": "Tuesday, 24 Nov 2026, 05:05:54 pm IST",
    "ipAddress": "::1",
    "status": "UNREAD",
    "googleSynced": true,
    "notes": null,
    "createdAt": "2026-11-24T11:35:54.000Z"
  }
];
